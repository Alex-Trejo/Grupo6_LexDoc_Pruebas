export class TimelineDTO {
  constructor({ number_events, process_id }) {
    this.number_events = number_events;
    this.process_id = process_id;
  }
}
