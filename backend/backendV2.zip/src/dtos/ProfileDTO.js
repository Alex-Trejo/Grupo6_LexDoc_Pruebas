export class ProfileDTO {
  constructor({ content, account_id }) {
    this.content = content;
    this.account_id = account_id;
  }
}
