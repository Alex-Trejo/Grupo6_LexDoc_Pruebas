export class ObservationDTO {
  constructor({ title, content, process_id }) {
    this.title = title;
    this.content = content;
    this.process_id = process_id;
  }
}
