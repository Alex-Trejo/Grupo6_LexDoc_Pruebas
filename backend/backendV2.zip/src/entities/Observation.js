export class Observation {
  constructor({ observation_id, title, content, process_id }) {
    this.observation_id = observation_id;
    this.title = title;
    this.content = content;
    this.process_id = process_id;
  }
}
