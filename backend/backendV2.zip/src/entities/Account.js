export class Account {
    constructor ({account_id, username, password, email, phone_number}) 
    {
        this.account_id = account_id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.phone_number = phone_number;
    }
}