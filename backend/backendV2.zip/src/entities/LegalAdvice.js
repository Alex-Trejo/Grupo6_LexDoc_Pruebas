export class LegalAdvice {
  constructor({ advice_id, content, process_id }) {
    this.advice_id = advice_id;
    this.content = content;
    this.process_id = process_id;
  }
}
