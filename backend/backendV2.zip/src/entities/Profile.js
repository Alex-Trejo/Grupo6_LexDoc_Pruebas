export class Profile {
  constructor({ profile_id, content, account_id }) {
    this.profile_id = profile_id;
    this.content = content;
    this.account_id = account_id;
  }
}
