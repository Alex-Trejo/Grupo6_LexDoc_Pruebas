export class Timeline {
  constructor({ timeline_id, number_events, process_id }) {
    this.timeline_id = timeline_id;
    this.number_events = number_events;
    this.process_id = process_id;
  }
}
